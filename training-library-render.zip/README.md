  Training Library - Render cloud addon + local backend

  Structure:
  - cloud-addon/   => deploy this on Render (or Fly/Railway)
  - local-backend/ => run on your PC to serve streams and local catalog

Quick steps:
  1) Deploy cloud-addon to Render. After deploy, get the HTTPS URL like https://your-app.onrender.com
  2) In Render, set environment variable LOCAL_BACKEND_URL to http://<YOUR_PC_IP>:7000 (optional but recommended)
  3) Start local backend on your PC (node local-backend/bootstrap.js and node local-backend/stream-server.js)
  4) In Stremio add addon using the cloud URL: stremio://https://your-app.onrender.com/manifest.json

If you want, I can prepare the ZIP for you to download now.

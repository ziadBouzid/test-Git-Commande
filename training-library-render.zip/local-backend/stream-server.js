// local-backend/stream-server.js
const express = require('express');
const fs = require('fs');
const path = require('path');
const os = require('os');
require('dotenv').config();
const app = express();
const PORT = process.env.STREAM_PORT || 8888;

const MIME_MAP = {
  '.mp4': 'video/mp4',
  '.mkv': 'video/x-matroska',
  '.avi': 'video/x-msvideo',
  '.mov': 'video/quicktime',
  '.webm': 'video/webm',
  '.m4v': 'video/x-m4v',
  '.flv': 'video/x-flv',
  '.wmv': 'video/x-ms-wmv'
};

app.get('/stream', (req,res)=>{
  const file = req.query.path;
  if (!file) return res.status(400).send('path required');
  const decoded = decodeURIComponent(file);
  if (!fs.existsSync(decoded)) return res.status(404).send('not found');
  const ext = path.extname(decoded).toLowerCase();
  const mimeType = MIME_MAP[ext] || 'application/octet-stream';
  const stat = fs.statSync(decoded);
  const total = stat.size;
  const range = req.headers.range;
  if (!range) {
    res.writeHead(200, { 'Content-Length': total, 'Content-Type': mimeType });
    fs.createReadStream(decoded).pipe(res);
  } else {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : total - 1;
    const chunksize = (end - start) + 1;
    const fileStream = fs.createReadStream(decoded, { start, end });
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${total}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': mimeType
    });
    fileStream.pipe(res);
  }
});

app.listen(PORT, ()=> console.log('Stream server listening on', PORT));

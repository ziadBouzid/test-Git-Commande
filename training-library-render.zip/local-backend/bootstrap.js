// local-backend/bootstrap.js
// Minimal local backend: exposes simple API endpoints used by cloud addon.
const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 7000;

// Simple in-memory sample DB (you will replace with Mongo later)
const SAMPLE = [
  { id: 'course1', title: 'JavaScript Essentials', platform: 'webdev', cover: 'https://via.placeholder.com/300x450.png?text=JS', description: 'Intro to JS', videos: [] },
  { id: 'course2', title: 'React Mastery', platform: 'linkedin', cover: 'https://via.placeholder.com/300x450.png?text=React', description: 'Learn React', videos: [] }
];

app.get('/api/health', (req,res)=> res.json({ ok: true }));

app.get('/api/catalog', (req,res)=>{
  const metas = SAMPLE.map(c=>({ id: c.id, type: 'other', name: c.title, poster: c.cover, description: c.description }));
  res.json({ metas });
});

app.get('/api/meta/:id', (req,res)=>{
  const id = req.params.id;
  const course = SAMPLE.find(c=>c.id===id);
  if (!course) return res.json({ meta: {} });
  res.json({ meta: { id: course.id, type: 'other', name: course.title, poster: course.cover, description: course.description, videos: course.videos } });
});

// Stream server endpoint (the real stream server will be separate, but here we provide sample)
app.get('/api/streaminfo/:id', (req,res)=>{
  // This would return local stream URL(s) for a given video id
  res.json({ streams: [] });
});

app.listen(PORT, ()=> console.log('Local backend listening on port', PORT, 'API: /api/catalog , /api/meta/:id'));    

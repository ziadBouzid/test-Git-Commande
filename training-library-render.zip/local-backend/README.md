Local backend instructions
--------------------------
1) Node.js v18+ required
2) cd local-backend
3) npm install
4) node bootstrap.js   # starts local API on port 7000
5) node stream-server.js  # starts stream server on port 8888 (range supported)

Environment variables (optional):
  PORT=7000
  STREAM_PORT=8888
  MONGO_URI=auto
  BING_API_KEY=REPLACE_ME

Usage with cloud addon:
  - Deploy cloud-addon and set LOCAL_BACKEND_URL to http://<your_pc_ip>:7000
  - Cloud will proxy catalog/meta to your local backend when available
  - Stremio will use cloud manifest (https) so it works even under tethering/strict networks

// cloud-addon/index.js
// Simple Render-ready cloud addon that serves manifest, catalog, meta.
// It can optionally proxy to a local backend if LOCAL_BACKEND_URL env var is set.
const express = require('express');
const axios = require('axios');
const app = express();
const PORT = process.env.PORT || 3000;
const LOCAL_BACKEND = process.env.LOCAL_BACKEND_URL || null; // ex: http://YOUR_PC_IP:7000

const MANIFEST = {
  id: process.env.MANIFEST_ID || 'org.local.courses',
  version: '1.0.0',
  name: process.env.ADDON_NAME || 'Training Library',
  description: 'Cloud manifest for Training Library - proxies catalog/meta to local backend when available',
  resources: ['catalog','meta','stream'],
  types: ['other'],
  catalogs: [{ type: 'other', id: 'training-catalog', name: process.env.ADDON_NAME || 'Training Library' }]
};

app.get('/manifest.json', (req,res)=>{
  res.json(MANIFEST);
});

// Catalog: try local backend first, otherwise return sample
app.get('/catalog/:type/:id.json', async (req,res)=>{
  if (LOCAL_BACKEND) {
    try {
      const r = await axios.get(LOCAL_BACKEND.replace(/\/$/,'') + '/api/catalog');
      return res.json(r.data);
    } catch (e) {
      console.warn('Local backend unavailable:', e.message);
    }
  }
  // fallback sample
  const metas = [
    { id: 'sample-course', type: 'other', name: 'Sample Course', poster: 'https://via.placeholder.com/300x450.png?text=Sample', description: 'Fallback sample course' }
  ];
  res.json({ metas });
});

// Meta: try local backend first, otherwise sample
app.get('/meta/:type/:id.json', async (req,res)=>{
  const id = req.params.id;
  if (LOCAL_BACKEND) {
    try {
      const r = await axios.get(LOCAL_BACKEND.replace(/\/$/,'') + '/api/meta/' + encodeURIComponent(id));
      return res.json(r.data);
    } catch (e) {
      console.warn('Local backend unavailable:', e.message);
    }
  }
  res.json({ meta: { id, type: 'other', name: 'Sample Course', poster: 'https://via.placeholder.com/300x450.png?text=Sample', description: 'Fallback meta', videos: [] } });
});

// Stream: cloud does not stream videos; left empty or proxy small info
app.get('/stream/:type/:id.json', (req,res)=>{
  res.json({ streams: [] });
});

app.get('/', (req,res)=> res.send('Training Library cloud addon - manifest at /manifest.json'));

app.listen(PORT, ()=> console.log('Cloud addon listening on port', PORT, 'MANIFEST -> /manifest.json'));    

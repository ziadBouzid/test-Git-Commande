Cloud addon (Render) instructions
--------------------------------
1) Create an account on Render.com
2) Create a new Web Service, choose "Deploy from ZIP" or connect to GitHub
3) Upload this cloud-addon folder as a ZIP or point to a Git repo

4) Set environment variables (optional):
   - MANIFEST_ID (default org.local.courses)
   - ADDON_NAME (default 'Training Library')
   - LOCAL_BACKEND_URL (e.g. http://YOUR_PC_IP:7000) to enable catalog/meta proxy to your local backend

5) Deploy. You will get a URL like https://your-app.onrender.com/manifest.json

6) Add that URL in Stremio (stremio://https://your-app.onrender.com/manifest.json) or via Add-ons -> Discover -> Local Addons

